package com.example.mylloydsassignment

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import com.example.presentation.HomeActivity

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startActivity(Intent(this, HomeActivity::class.java))
    }
}