package com.example.lloydsassignment.domain.usecases

import com.example.lloydsassignment.data.models.UserDto
import com.example.lloydsassignment.domain.model.UserListModel
import kotlinx.coroutines.flow.StateFlow

interface GetUserUseCase {
    suspend fun getUsers(): StateFlow<UserListModel>
}