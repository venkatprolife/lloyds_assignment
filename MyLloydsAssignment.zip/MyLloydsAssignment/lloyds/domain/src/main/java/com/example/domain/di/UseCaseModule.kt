package com.example.lloydsassignment.domain.di

import com.example.lloydsassignment.domain.repository.DetailRepository
import com.example.lloydsassignment.domain.repository.DetailRepositoryDomain
import com.example.lloydsassignment.domain.repository.UserRepository
import com.example.lloydsassignment.domain.repository.UserRepositoryDomain
import com.example.lloydsassignment.domain.usecases.GetUserDetailUseCase
import com.example.lloydsassignment.domain.usecases.GetUserDetailUseCaseImpl
import com.example.lloydsassignment.domain.usecases.GetUserUseCase
import com.example.lloydsassignment.domain.usecases.GetUserUseCaseImpl
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
class UseCaseModule {

    @Provides
    fun provideGetUserUseCase(userRepositoryDmain: UserRepositoryDomain):GetUserUseCase {
        return GetUserUseCaseImpl(userRepositoryDmain)
    }

    @Provides
    fun provideGetUserDetailUseCase(detailRepositoryDomain: DetailRepositoryDomain):GetUserDetailUseCase {
        return GetUserDetailUseCaseImpl(detailRepositoryDomain)
    }
}