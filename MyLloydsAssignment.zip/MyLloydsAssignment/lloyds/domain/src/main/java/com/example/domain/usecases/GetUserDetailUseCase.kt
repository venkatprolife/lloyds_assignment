package com.example.lloydsassignment.domain.usecases

import com.example.lloydsassignment.data.models.UserDto
import com.example.lloydsassignment.domain.model.UserModel
import kotlinx.coroutines.flow.StateFlow

interface GetUserDetailUseCase {
    suspend fun getUserById(id: String): StateFlow<UserModel?>
}