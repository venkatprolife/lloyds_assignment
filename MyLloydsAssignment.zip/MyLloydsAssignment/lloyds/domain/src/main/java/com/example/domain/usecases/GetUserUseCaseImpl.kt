package com.example.lloydsassignment.domain.usecases

import com.example.lloydsassignment.domain.model.UserListModel
import com.example.lloydsassignment.domain.repository.UserRepository
import com.example.lloydsassignment.domain.repository.UserRepositoryDomain
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject

class GetUserUseCaseImpl @Inject constructor(private val userRepositoryDomain: UserRepositoryDomain): GetUserUseCase {

    override suspend fun getUsers(): StateFlow<UserListModel> {
        // Perform any necessary business logic or data transformations here
        return userRepositoryDomain.getUsers()
    }
}