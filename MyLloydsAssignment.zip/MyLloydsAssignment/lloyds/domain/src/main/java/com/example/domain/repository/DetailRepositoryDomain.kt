package com.example.lloydsassignment.domain.repository

import com.example.lloydsassignment.domain.model.UserModel
import kotlinx.coroutines.flow.StateFlow

interface DetailRepositoryDomain {
    suspend fun getUserById(id: String): StateFlow<UserModel?>
}