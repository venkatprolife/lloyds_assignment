package com.example.lloydsassignment.domain.model

data class UserListModel(var userList: List<UserModel> = emptyList())