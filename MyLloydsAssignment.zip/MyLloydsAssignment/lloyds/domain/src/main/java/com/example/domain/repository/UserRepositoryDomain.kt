package com.example.lloydsassignment.domain.repository

import com.example.lloydsassignment.domain.model.UserListModel
import kotlinx.coroutines.flow.StateFlow

interface UserRepositoryDomain {
    suspend fun getUsers(): StateFlow<UserListModel>
}