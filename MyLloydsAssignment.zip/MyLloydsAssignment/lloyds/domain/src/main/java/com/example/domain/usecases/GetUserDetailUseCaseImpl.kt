package com.example.lloydsassignment.domain.usecases

import com.example.lloydsassignment.data.models.UserDto
import com.example.lloydsassignment.domain.model.UserModel
import com.example.lloydsassignment.domain.repository.DetailRepository
import com.example.lloydsassignment.domain.repository.DetailRepositoryDomain
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject

class GetUserDetailUseCaseImpl @Inject constructor(private val detailRepositoryDomain: DetailRepositoryDomain): GetUserDetailUseCase {

    override suspend fun getUserById(id: String): StateFlow<UserModel?> {
        // Perform any necessary business logic or data transformations here
        return detailRepositoryDomain.getUserById(id)
    }
}