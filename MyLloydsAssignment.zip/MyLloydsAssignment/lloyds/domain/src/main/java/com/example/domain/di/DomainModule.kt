package com.example.lloydsassignment.data.di

import com.example.domain.repository.DetailRepositoryDomainImpl
import com.example.domain.repository.DetailRepositoryImpl
import com.example.domain.repository.UserRepositoryDomainImpl
import com.example.domain.repository.UserRepositoryImpl
import com.example.lloydsassignment.data.services.DetailApiService
import com.example.lloydsassignment.data.services.UsersApiService
import com.example.lloydsassignment.domain.repository.DetailRepository
import com.example.lloydsassignment.domain.repository.DetailRepositoryDomain
import com.example.lloydsassignment.domain.repository.UserRepository
import com.example.lloydsassignment.domain.repository.UserRepositoryDomain
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
class DomainModule {

    @Provides
    fun provideUserRepoDomain(userRepository: UserRepository) : UserRepositoryDomain {
        return UserRepositoryDomainImpl(userRepository)
    }

    @Provides
    fun provideDetailRepoDomain(detailRepository: DetailRepository) : DetailRepositoryDomain {
        return DetailRepositoryDomainImpl(detailRepository)
    }
}