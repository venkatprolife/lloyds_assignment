package com.example.lloydsassignment.data.models

data class SingleUserDto(
    val data: UserDto
)