package com.example.lloydsassignment.domain.repository

import com.example.lloydsassignment.data.models.UserDto
import kotlinx.coroutines.flow.StateFlow

interface DetailRepository {
    val userDto: StateFlow<UserDto?>
    suspend fun getUserById(id: String)
}