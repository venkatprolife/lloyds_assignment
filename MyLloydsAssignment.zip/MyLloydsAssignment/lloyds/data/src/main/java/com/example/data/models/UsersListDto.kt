package com.example.lloydsassignment.data.models

data class UsersListDto(
    val data: List<UserDto> = emptyList()
)