package com.example.lloydsassignment.data.services

import com.example.lloydsassignment.data.models.SingleUserDto
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path

interface DetailApiService {
    @GET("/api/users/{id}")
    suspend fun getUserById(@Path("id") id: String) : Response<SingleUserDto>
}