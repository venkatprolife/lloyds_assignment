package com.example.lloydsassignment.data.services

import com.example.lloydsassignment.data.models.UsersListDto
import retrofit2.Response
import retrofit2.http.GET

interface UsersApiService {
    @GET("/api/users")
    suspend fun getUsers() : Response<UsersListDto>
}