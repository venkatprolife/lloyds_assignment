package com.example.lloydsassignment.domain.repository

import com.example.lloydsassignment.data.models.UsersListDto
import kotlinx.coroutines.flow.StateFlow

interface UserRepository {
    val userListDto:StateFlow<UsersListDto>
    suspend fun getUsers()
}