package com.example.presentation.viewmodels

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.SavedStateHandle
import com.example.lloydsassignment.domain.model.UserModel
import com.example.lloydsassignment.domain.usecases.GetUserDetailUseCase
import com.example.lloydsassignment.presentation.viewmodels.DetailViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule

import org.junit.Test
import org.mockito.ArgumentMatchers
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.MockitoAnnotations

class DetailViewModelTest {

    private val testDispatcher = StandardTestDispatcher()

    @get:Rule
    val instantTaskExecutorRule = InstantTaskExecutorRule()

    @Mock
    lateinit var getUserDetailUseCase: GetUserDetailUseCase

    @Mock
    lateinit var savedStateHandle: SavedStateHandle

    @Before
    fun setUp() {
        MockitoAnnotations.openMocks(this)
        Dispatchers.setMain(testDispatcher)
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun getUserModel() = runTest {
        Mockito.`when`(getUserDetailUseCase.getUserById(ArgumentMatchers.anyString()))
            .thenReturn(MutableStateFlow(UserModel()))

        val viewModel = DetailViewModel(getUserDetailUseCase, savedStateHandle)
        viewModel.getUser()
        assertEquals(0, viewModel.userModel.value?.id)
    }


    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }
}