package com.example.presentation.viewmodels

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.example.lloydsassignment.domain.model.UserListModel
import com.example.lloydsassignment.domain.usecases.GetUserUseCase
import com.example.lloydsassignment.presentation.viewmodels.UsersViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.MockitoAnnotations

class UserViewModelTest {

    private val testDispatcher = StandardTestDispatcher()

    @get:Rule
    val instantTaskExecutorRule = InstantTaskExecutorRule()

    @Mock
    lateinit var getUserUseCase: GetUserUseCase

    @Before
    fun setUp() {
        MockitoAnnotations.openMocks(this)
        Dispatchers.setMain(testDispatcher)
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun getUserModel() = runTest {
        Mockito.`when`(getUserUseCase.getUsers())
            .thenReturn(MutableStateFlow(UserListModel()))

        val viewModel = UsersViewModel(getUserUseCase)
        viewModel.getUserList()
        Assert.assertEquals(0, viewModel.userList.value.userList.size)
    }


    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }
}