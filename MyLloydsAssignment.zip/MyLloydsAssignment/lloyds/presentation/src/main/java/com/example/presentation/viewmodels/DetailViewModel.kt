package com.example.lloydsassignment.presentation.viewmodels

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.lloydsassignment.domain.model.UserModel
import com.example.lloydsassignment.domain.usecases.GetUserDetailUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DetailViewModel @Inject constructor(private val getUserDetailUseCase: GetUserDetailUseCase, private val savedStateHandle: SavedStateHandle) : ViewModel() {
    private val _userModel = MutableStateFlow(UserModel())
    val userModel : StateFlow<UserModel?> get() = _userModel

    fun getUser() {
        viewModelScope.launch {
            val userid = savedStateHandle.get<String>("userid") ?: "2"
            val result = getUserDetailUseCase.getUserById(userid)
            _userModel.emit(result.value!!)
        }
    }
}